import json

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event))
    print("Simulating sending confirmation email to user...")
    return {
        'statusCode': 200,
        'body': json.dumps('Confirmation email sent successfully!')
    }
